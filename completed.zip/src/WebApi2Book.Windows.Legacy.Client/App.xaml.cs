﻿// App.xaml.cs
// Copyright Jamie Kurtz, Brian Wortman 2014.

using System.Windows;

namespace WebApi2Book.Windows.Legacy.Client
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}