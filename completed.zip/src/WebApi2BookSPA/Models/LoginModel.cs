﻿// LoginModel.cs
// Copyright Jamie Kurtz, Brian Wortman 2014.

namespace WebApi2BookSPA.Models
{
    public class LoginModel
    {
        public string UserId { get; set; }
        public string Role { get; set; }
    }
}